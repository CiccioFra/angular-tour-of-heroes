export interface Hero {   // questa è una interfaccia
    id: number;
    name: string;
  }