import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'il tour degli Heroes 2'; 
  //si può tipizzare:   title: string = 'angular-tour-of-heroes'; 

}
